<!DOCTYPE html>

<html lang="en">

 <head>
 	
 	

	 
	 <link rel="preconnect" href="https://fonts.googleapis.com">


	 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css" integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous"/>

     
     
     <link rel="stylesheet" href="<?php echo e(asset('new-assets/vendors/mdi/css/materialdesignicons.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('new-assets/vendors/css/vendor.bundle.base.css')); ?>">
     <!-- endinject -->
     <!-- Plugin css for this page -->
     <link rel="stylesheet" href="<?php echo e(asset('new-assets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>">
     <link rel="stylesheet" href="<?php echo e(asset('new-assets/vendors/jvectormap/jquery-jvectormap.css')); ?>">
     <!-- End plugin css for this page -->
     <!-- Layout styles -->

     <link rel="stylesheet" href="<?php echo e(asset('new-assets/css/demo/style.css')); ?>">
     <!-- End layout styles -->
     <link rel="shortcut icon" href="<?php echo e(asset('new-assets/images/favicon.png')); ?>" />

     

   <?php echo $__env->make('layouts.backend.partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 </head>

 <body class="fix-header fix-sidebar card-no-border">
    
	<!-- ============================================================== -->
    <!-- Main wrapper - style you can find in pages.scss -->
    <!-- ============================================================== -->
    <div id="main-wrapper">
		<?php echo $__env->make('layouts.backend.partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<?php echo $__env->make('layouts.backend.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<div class="page-wrapper">
		<?php echo $__env->yieldContent('content'); ?>

		</div>

		<?php echo $__env->make('layouts.backend.partials.footer-scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	</div>

    
    
    
    <script src="<?php echo e(asset('new-assets/vendors/jvectormap/jquery-jvectormap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('new-assets/vendors/jvectormap/jquery-jvectormap-world-mill-en.js')); ?>"></script>
    <script src="<?php echo e(asset('new-assets/js/material.js')); ?>"></script>
    <script src="<?php echo e(asset('new-assets/js/misc.js')); ?>"></script>
    <script src="<?php echo e(asset('new-assets/js/dashboard.js')); ?>"></script>
    <script src="<?php echo e(asset('new-assets/vendors/chartjs/Chart.min.js')); ?>"></script>
    


 </body>


</html>
<?php /**PATH C:\xampp\htdocs\wizbrand\wz-account-admin-ms\resources\views/layouts/backend/mainlayout.blade.php ENDPATH**/ ?>