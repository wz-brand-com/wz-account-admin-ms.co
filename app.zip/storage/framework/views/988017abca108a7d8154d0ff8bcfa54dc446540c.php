<meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Tell the browser to be responsive to screen width -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <meta name="description" content="">
    <meta name="author" content="">
    <!-- Favicon icon -->
    <link rel="icon" type="image/png" sizes="16x16" href="<?php echo e(asset('assets/images/favicon.png')); ?>">
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name', 'wizbrand')); ?></title>
    <!-- Bootstrap Core CSS -->
    <!-- Custom CSS -->
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
    <script src="<?php echo e(asset('new-assets/vendors/js/vendor.bundle.base.js')); ?>"></script><?php /**PATH C:\xampp\htdocs\wizbrand\wz-account-admin-ms\resources\views/layouts/backend/partials/head.blade.php ENDPATH**/ ?>