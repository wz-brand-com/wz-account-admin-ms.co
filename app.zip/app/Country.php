<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Country extends Model
{
    protected
     $table = "countries";
    
      



    //  public function Profile()
    //  {
    //    return $this->hasMany('App\Profile','foreign_key','country');
    //  }
    //  public function profile()
    //  {
    //      return $this->belongsTo('App\Profile');
    //  }




}

