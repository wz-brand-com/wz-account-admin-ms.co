<?php return array (
  'app' => 
  array (
    'name' => 'Wizbrand',
    'env' => 'local',
    'debug' => true,
    'url' => 'https://www.wizbrand.com/',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:eBFlTIuSszhALs0Z4MDGhYqQdxUo8OM3x+LlyEW4Bz4=',
    'cipher' => 'AES-256-CBC',
    'SD_ORGANISATION_TYPE_MS_BASE_URL' => 'http://wz-organisation-ms',
    'SD_ORGANISATION_TYPE_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_ORGANISATION_TYPE_MS_GRAND_TYPE' => 'client_credentials',
    'SD_ORGANISATION_TYPE_MS_CLIENT_ID' => '3',
    'SD_ORGANISATION_TYPE_MS_SECRET' => 'KZwtCpbah9GivCuBhrzi5gBSPMmVShhq0Yd3as9M',
    'SD_ORGANISATION_TYPE_MS_ALL_URL' => '/api/v1/j/organization_types',
    'SD_ORGANISATION_TYPE_MS_STORE_URL' => '/api/v1/j/organization_types/store',
    'SD_ORGANISATION_TYPE_MS_EDIT' => '/api/v1/j/organization_types/edit',
    'SD_ORGANISATION_TYPE_MS_UPDATE' => '/api/v1/j/organization_types/update',
    'SD_ORGANISATION_TYPE_MS_DELETE_URL' => '/api/v1/j/organization_types/destroy',
    'SD_ORGANISATION_TYPE_MS_DASHBOARD_URL' => '/api/v1/j/organization_types/getSlugDashboard',
    'SD_ORGANISATION_TYPE_MS_STORE_ROLE_ORG_NAME_URL' => '/api/v1/j/organization_types/storeRoleOrgName',
    'SD_ADMIN_MS_BASE_URL' => 'not found in .env file',
    'SD_ADMIN_MS_OAUTH_TOKEN_URL' => 'not found in .env file',
    'SD_ADMIN_MS_GRAND_TYPE' => 'not found in .env file',
    'SD_ADMIN_MS_CLIENT_ID' => 'not found in .env file',
    'SD_ADMIN_MS_SECRET' => 'not found in .env file',
    'SD_ADMIN_MS_ALL_URL' => 'not found in .env file',
    'SD_ADMIN_MS_STORE_URL' => 'not found in .env file',
    'SD_ADMIN_MS_EDIT' => 'not found in .env file',
    'SD_ADMIN_MS_UPDATE' => 'not found in .env file',
    'SD_ADMIN_MS_DELETE_URL' => 'not found in .env file',
    'SD_MANAGER_MS_BASE_URL' => 'not found in .env file',
    'SD_MANAGER_MS_OAUTH_TOKEN_URL' => 'not found in .env file',
    'SD_MANAGER_MS_GRAND_TYPE' => 'not found in .env file',
    'SD_MANAGER_MS_CLIENT_ID' => 'not found in .env file',
    'SD_MANAGER_MS_SECRET' => 'not found in .env file',
    'SD_MANAGER_MS_ALL_URL' => 'not found in .env file',
    'SD_MANAGER_MS_STORE_URL' => 'not found in .env file',
    'SD_MANAGER_MS_EDIT' => 'not found in .env file',
    'SD_MANAGER_MS_UPDATE' => 'not found in .env file',
    'SD_MANAGER_MS_DELETE_URL' => 'not found in .env file',
    'SD_TASK_TYPE_SITE_ADMIN_MS_BASE_URL' => 'http://siteadmin',
    'SD_TASK_TYPE_SITE_ADMIN_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_TASK_TYPE_SITE_ADMIN_MS_GRAND_TYPE' => 'client_credentials',
    'SD_TASK_TYPE_SITE_ADMIN_MS_CLIENT_ID' => '7',
    'SD_TASK_TYPE_SITE_ADMIN_MS_SECRET' => 'nzZywsQv9PcRrX3Ds3WMILuZDsAG6jdCBiKeZN5F',
    'SD_TASK_TYPE_SITE_ADMIN_MS_ALL_URL' => '/api/v1/j/siteAdminTask',
    'SD_TASK_TYPE_MS_BASE_URL' => 'http://wz-task-type-ms',
    'SD_TASK_TYPE_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_TASK_TYPE_MS_GRAND_TYPE' => 'client_credentials',
    'SD_TASK_TYPE_MS_CLIENT_ID' => '7',
    'SD_TASK_TYPE_MS_SECRET' => 'ClS74y5eJzU91hDzWuSpGZKFBrrbDCQTcOGz2JHg',
    'SD_TASK_TYPE_MS_ALL_URL' => '/api/v1/j/task',
    'SD_TASK_TYPE_MS_STORE_URL' => '/api/v1/j/task/store',
    'SD_TASK_TYPE_MS_EDIT' => '/api/v1/j/task/edit',
    'SD_TASK_TYPE_MS_UPDATE' => '/api/v1/j/task/update',
    'SD_TASK_TYPE_MS_DELETE_URL' => '/api/v1/j/task/destroy',
    'SD_PROJECTS_MS_BASE_URL' => 'http://wz-projects-ms',
    'SD_PROJECTS_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_PROJECTS_MS_GRAND_TYPE' => 'client_credentials',
    'SD_PROJECTS_MS_CLIENT_ID' => '5',
    'SD_PROJECTS_MS_SECRET' => 'QsCiL5oTY91W2MzYRnAV5L5tSOMp5R1eglj2Cq9c',
    'SD_PROJECTS_MS_ALL_URL' => '/api/v1/j/project',
    'SD_PROJECTS_MS_STORE_URL' => '/api/v1/j/project/store',
    'SD_PROJECTS_MS_EDIT' => '/api/v1/j/project/edit',
    'SD_PROJECTS_MS_UPDATE' => '/api/v1/j/project/update',
    'SD_PROJECTS_MS_DELETE_URL' => '/api/v1/j/project/destroy',
    'SD_USERS_MANAGER_MS_BASE_URL' => 'http://wz-user-manager-ms',
    'SD_USERS_MANAGER_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_USERS_MANAGER_MS_GRAND_TYPE' => 'client_credentials',
    'SD_USERS_MANAGER_MS_CLIENT_ID' => '1',
    'SD_USERS_MANAGER_MS_SECRET' => 'x2nCte7ZOeLMlZYTKpCoULhYBPonziUOvmcDmsnu',
    'SD_USERS_MANAGER_MS_ALL_URL' => '/api/v1/j/usermanager',
    'SD_USERS_MANAGER_MS_STORE_URL' => '/api/v1/j/usermanager/store',
    'SD_USERS_MANAGER_MS_EDIT' => '/api/v1/j/usermanager/edit',
    'SD_USERS_MANAGER_MS_UPDATE' => '/api/v1/j/usermanager/update_u_m',
    'SD_USERS_MANAGER_MS_DELETE_URL' => '/api/v1/j/usermanager/destroy_u_m',
    'SD_USER_MS_BASE_URL' => 'not found in .env file',
    'SD_USER_MS_OAUTH_TOKEN_URL' => 'not found in .env file',
    'SD_USER_MS_GRAND_TYPE' => 'not found in .env file',
    'SD_USER_MS_CLIENT_ID' => 'not found in .env file',
    'SD_USER_MS_SECRET' => 'not found in .env file',
    'SD_USER_MS_ALL_URL' => 'not found in .env file',
    'SD_USER_MS_STORE_URL' => 'not found in .env file',
    'SD_USER_MS_EDIT' => 'not found in .env file',
    'SD_USER_MS_UPDATE' => 'not found in .env file',
    'SD_USER_MS_DELETE_URL' => 'not found in .env file',
    'SD_ADD_URLS_MS_BASE_URL' => 'http://wz-add-urls-ms',
    'SD_ADD_URLS_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_ADD_URLS_MS_GRAND_TYPE' => 'client_credentials',
    'SD_ADD_URLS_MS_CLIENT_ID' => '7',
    'SD_ADD_URLS_MS_SECRET' => 'UERan0c1sCzuZ124D4zXBWsaf4BYmeOnJhTGCbsH',
    'SD_ADD_URLS_MS_ALL_URL' => '/api/v1/j/addurl',
    'SD_ADD_URLS_MS_STORE_URL' => '/api/v1/j/addurl/store',
    'SD_ADD_URLS_MS_EDIT' => '/api/v1/j/addurl/edit',
    'SD_ADD_URLS_MS_UPDATE' => '/api/v1/j/addurl/update',
    'SD_ADD_URLS_MS_DELETE_URL' => '/api/v1/j/addurl/destroy',
    'SD_ADD_URLS_MS_GETPROJECT_URL' => '/api/v1/j/addurl/getProject',
    'SD_KEYWORDS_MS_BASE_URL' => 'http://wz-keywords-ms',
    'SD_KEYWORDS_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_KEYWORDS_MS_GRAND_TYPE' => 'client_credentials',
    'SD_KEYWORDS_MS_CLIENT_ID' => '5',
    'SD_KEYWORDS_MS_SECRET' => 'kzz4ccbcPtVOoi6UGVKqPoLRoljKwUlQrHKAPGg1',
    'SD_KEYWORDS_MS_ALL_URL' => '/api/v1/j/keyword',
    'SD_KEYWORDS_MS_STORE_URL' => '/api/v1/j/keyword/store',
    'SD_KEYWORDS_MS_EDIT' => '/api/v1/j/keyword/edit',
    'SD_KEYWORDS_MS_UPDATE' => '/api/v1/j/keyword/update',
    'SD_KEYWORDS_MS_DELETE_URL' => '/api/v1/j/keyword/destroy',
    'SD_KEYWORDS_MS_GETKEYWORD_URL' => '/api/v1/j/keyword/getKeywordData',
    'SD_TEAM_RATING_MS_BASE_URL' => 'http://wz-team-rating-ms',
    'SD_TEAM_RATING_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_TEAM_RATING_MS_GRAND_TYPE' => 'client_credentials',
    'SD_TEAM_RATING_MS_CLIENT_ID' => '5',
    'SD_TEAM_RATING_MS_SECRET' => 'DyfbdllKTy9RXa1k9PbeAACZQbdWVxcnMvONVLLr',
    'SD_TEAM_RATING_MS_ALL_URL' => '/api/v1/j/rating',
    'SD_TEAM_RATING_MS_STORE_URL' => '/api/v1/j/rating/store',
    'SD_TEAM_RATING_MS_EDIT' => '/api/v1/j/rating/edit',
    'SD_TEAM_RATING_MS_UPDATE' => '/api/v1/j/rating/update',
    'SD_TEAM_RATING_MS_DELETE_URL' => '/api/v1/j/rating/destroy',
    'SD_WEBSITE_RANKING_MS_BASE_URL' => 'http://wz-website-ranking-ms',
    'SD_WEBSITE_RANKING_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_WEBSITE_RANKING_MS_GRAND_TYPE' => 'client_credentials',
    'SD_WEBSITE_RANKING_MS_CLIENT_ID' => '7',
    'SD_WEBSITE_RANKING_MS_SECRET' => 'Qlcvee2SpfAz8nM6GnDTxGfAQi7kkMdmMS1IT4K4',
    'SD_WEBSITE_RANKING_MS_ALL_URL' => '/api/v1/j/webrank',
    'SD_WEBSITE_RANKING_MS_STORE_URL' => '/api/v1/j/webrank/store',
    'SD_WEBSITE_RANKING_MS_DELETE_URL' => '/api/v1/j/webrank/destroy',
    'SD_WEBSITE_RANKING_MS_EDIT' => '/api/v1/j/webrank/edit',
    'SD_WEBSITE_RANKING_MS_UPDATE' => '/api/v1/j/webrank/update',
    'SD_PAGE_RANKING_MS_BASE_URL' => 'http://wz-page-ranking-ms',
    'SD_PAGE_RANKING_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_PAGE_RANKING_MS_GRAND_TYPE' => 'client_credentials',
    'SD_PAGE_RANKING_MS_CLIENT_ID' => '5',
    'SD_PAGE_RANKING_MS_SECRET' => 'WG2JgRGwyyoXpnX9sY2DJO59Hgn4jw4YnCAOUO8b',
    'SD_PAGE_RANKING_MS_ALL_URL' => '/api/v1/j/pagerank',
    'SD_PAGE_RANKING_MS_STORE_URL' => '/api/v1/j/pagerank/store',
    'SD_PAGE_RANKING_MS_EDIT' => '/api/v1/j/pagerank/edit',
    'SD_PAGE_RANKING_MS_UPDATE' => '/api/v1/j/pagerank/update',
    'SD_PAGE_RANKING_MS_DELETE_URL' => '/api/v1/j/pagerank/destroy',
    'SD_SOCIAL_RANKING_MS_BASE_URL' => 'http://wz-social-ranking-ms',
    'SD_SOCIAL_RANKING_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_SOCIAL_RANKING_MS_GRAND_TYPE' => 'client_credentials',
    'SD_SOCIAL_RANKING_MS_CLIENT_ID' => '7',
    'SD_SOCIAL_RANKING_MS_SECRET' => 'GA5ZnSUCWC8PMUKZCzvgZIAmndmZMDJJ6F44TrLn',
    'SD_SOCIAL_RANKING_MS_ALL_URL' => '/api/v1/j/socialrank',
    'SD_SOCIAL_RANKING_MS_STORE_URL' => '/api/v1/j/socialrank/store',
    'SD_SOCIAL_RANKING_MS_EDIT' => '/api/v1/j/socialrank/edit',
    'SD_SOCIAL_RANKING_MS_UPDATE' => '/api/v1/j/socialrank/update',
    'SD_SOCIAL_RANKING_MS_DELETE_URL' => '/api/v1/j/socialrank/destroy',
    'SD_WEBSITE_ACCESS_MS_BASE_URL' => 'http://wz-website-access-ms',
    'SD_WEBSITE_ACCESS_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_WEBSITE_ACCESS_MS_GRAND_TYPE' => 'client_credentials',
    'SD_WEBSITE_ACCESS_MS_CLIENT_ID' => '5',
    'SD_WEBSITE_ACCESS_MS_SECRET' => 'R6z6F2apD4g2PLR0KW8rfwEpJdQlUwvf8ONHeKyr',
    'SD_WEBSITE_ACCESS_MS_ALL_URL' => '/api/v1/j/webaccess',
    'SD_WEBSITE_ACCESS_MS_STORE_URL' => '/api/v1/j/webaccess/store',
    'SD_WEBSITE_ACCESS_MS_EDIT' => '/api/v1/j/webaccess/edit',
    'SD_WEBSITE_ACCESS_MS_UPDATE' => '/api/v1/j/webaccess/update',
    'SD_WEBSITE_ACCESS_MS_DELETE_URL' => '/api/v1/j/webaccess/destroy',
    'SD_WEBSITE_ACCESS_MS_DECRYPT_ENCRYPT' => '/api/v1/j/webaccess/encrypt_decrypt',
    'SD_EMAIL_MS_BASE_URL' => 'http://wz-email-access-ms',
    'SD_EMAIL_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_EMAIL_MS_GRAND_TYPE' => 'client_credentials',
    'SD_EMAIL_MS_CLIENT_ID' => '9',
    'SD_EMAIL_MS_SECRET' => 'zpssdkf8u3Awh1V03CX5mjpsBD5PKVRQTxObj3u2',
    'SD_EMAIL_MS_ALL_URL' => '/api/v1/j/email',
    'SD_EMAIL_MS_STORE_URL' => '/api/v1/j/email/store',
    'SD_EMAIL_MS_DELETE_URL' => '/api/v1/j/email/destroy',
    'SD_EMAIL_MS_EDIT' => '/api/v1/j/email/edit',
    'SD_EMAIL_MS_UPDATE' => '/api/v1/j/email/update',
    'SD_PHONE_NUMBER_MS_BASE_URL' => 'http://wz-phone-number-ms',
    'SD_PHONE_NUMBER_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_PHONE_NUMBER_MS_GRAND_TYPE' => 'client_credentials',
    'SD_PHONE_NUMBER_MS_CLIENT_ID' => '7',
    'SD_PHONE_NUMBER_MS_SECRET' => 'e9qQAMdqsCkvbybr3fbqpCNWRHJaj98CLculOM8z',
    'SD_PHONE_NUMBER_MS_ALL_URL' => '/api/v1/j/phonenumber',
    'SD_PHONE_NUMBER_MS_STORE_URL' => '/api/v1/j/phonenumber/store',
    'SD_PHONE_NUMBER_MS_DELETE_URL' => '/api/v1/j/phonenumber/destroy',
    'SD_PHONE_NUMBER_MS_EDIT' => '/api/v1/j/phonenumber/edit',
    'SD_PHONE_NUMBER_MS_UPDATE' => '/api/v1/j/phonenumber/update',
    'SD_TASK_BOARD_MS_BASE_URL' => 'http://wz-tasks-board-ms',
    'SD_TASK_BOARD_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_TASK_BOARD_MS_GRAND_TYPE' => 'client_credentials',
    'SD_TASK_BOARD_MS_CLIENT_ID' => '5',
    'SD_TASK_BOARD_MS_SECRET' => 'kf8RLUKxM5YYxZVmi00FPfEGhWEphFffdRZzABu4',
    'SD_TASK_BOARD_MS_ALL_URL' => '/api/v1/j/taskboard',
    'SD_TASK_BOARD_MS_STORE_URL' => '/api/v1/j/taskboard/store',
    'SD_TASK_BOARD_MS_EDIT' => '/api/v1/j/taskboard/edit',
    'SD_TASK_BOARD_MS_UPDATE' => '/api/v1/j/taskboard/update',
    'SD_TASK_BOARD_MS_DELETE_URL' => '/api/v1/j/taskboard/destroy',
    'SD_INTERVAL_TASK_MS_BASE_URL' => 'http://wz-interval-task-ms',
    'SD_INTERVAL_TASK_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_INTERVAL_TASK_MS_GRAND_TYPE' => 'client_credentials',
    'SD_INTERVAL_TASK_MS_CLIENT_ID' => '5',
    'SD_INTERVAL_TASK_MS_SECRET' => 'PVNFWicUrLnkH6bNHAM7x66gwFeDc1Z0Q2Zo0mvj',
    'SD_INTERVAL_TASK_MS_ALL_URL' => '/api/v1/j/interval',
    'SD_INTERVAL_TASK_MS_STORE_URL' => '/api/v1/j/interval/store',
    'SD_INTERVAL_TASK_MS_DELETE_URL' => '/api/v1/j/interval/destroy',
    'SD_INTERVAL_TASK_MS_EDIT' => '/api/v1/j/interval/edit',
    'SD_INTERVAL_TASK_MS_UPDATE' => '/api/v1/j/interval/update',
    'SD_SUPER_ADMIN_MS_BASE_URL' => 'not found in .env file',
    'SD_SUPER_ADMIN_MS_OAUTH_TOKEN_URL' => 'not found in .env file',
    'SD_SUPER_ADMIN_MS_GRAND_TYPE' => 'not found in .env file',
    'SD_SUPER_ADMIN_MS_CLIENT_ID' => 'not found in .env file',
    'SD_SUPER_ADMIN_MS_TYPE_SECRET' => 'not found in .env file',
    'SD_SUPER_ADMIN_ALL_URL' => 'not found in .env file',
    'SD_SUPER_ADMIN_STORE_URL' => 'not found in .env file',
    'SD_SUPER_ADMIN_EDIT' => 'not found in .env file',
    'SD_SUPER_ADMIN_UPDATE' => 'not found in .env file',
    'SD_SUPER_ADMIN_DELETE_URL' => 'not found in .env file',
    'SD_WIZARD_PROJECT_MS_BASE_URL' => 'http://wz-wizard-project-ms',
    'SD_WIZARD_PROJECT_MS_OAUTH_TOKEN_URL' => '/oauth/token',
    'SD_WIZARD_PROJECT_MS_GRAND_TYPE' => 'client_credentials',
    'SD_WIZARD_PROJECT_MS_CLIENT_ID' => '3',
    'SD_WIZARD_PROJECT_MS_SECRET' => 'ZPqRL1baXeRk0KYL1UZEAZBSB935KMkPNjhsbana',
    'SD_WIZARD_PROJECT_MS_ALL_URL' => '/api/v1/j/wiz_projects',
    'SD_WIZARD_PROJECT_MS_STORE_URL' => '/api/v1/j/wiz_projects/store',
    'SD_WIZARD_PROJECT_MS_EDIT' => '/api/v1/j/wiz_projects/edit',
    'SD_WIZARD_PROJECT_MS_UPDATE' => '/api/v1/j/wiz_projects/update',
    'SD_WIZARD_PROJECT_MS_DELETE_URL' => '/api/v1/j/wiz_projects/destroy',
    'SD_WIZARD_PROJECT_MS_GETPROJECT_URL' => '/api/v1/j/wiz_projects/getprojectdata',
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'App\\Providers\\AppServiceProvider',
      23 => 'App\\Providers\\AuthServiceProvider',
      24 => 'App\\Providers\\EventServiceProvider',
      25 => 'App\\Providers\\RouteServiceProvider',
      26 => 'Laravel\\Passport\\PassportServiceProvider',
      27 => 'Anhskohbo\\NoCaptcha\\NoCaptchaServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Redis' => 'Illuminate\\Support\\Facades\\Redis',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'api' => 
      array (
        'driver' => 'passport',
        'provider' => 'users',
        'hash' => false,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\User',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_resets',
        'expire' => 60,
      ),
    ),
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'useTLS' => true,
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'C:\\xampp\\htdocs\\wizbrand\\wz-account-admin-ms\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
    ),
    'prefix' => 'wizbrand_cache',
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'wz_account_admin_ms',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'wz_account_admin_ms',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'mysqlManager' => 
      array (
        'driver' => 'mysql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'forge',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'strict' => false,
        'engine' => NULL,
      ),
      'mysqlSiteAdminTaskType' => 
      array (
        'driver' => 'mysql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'wz_siteadmin_ms',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'strict' => false,
        'engine' => NULL,
      ),
      'mysqlUser' => 
      array (
        'driver' => 'mysql',
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'forge',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'strict' => false,
        'engine' => NULL,
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'wz_account_admin_ms',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'schema' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'wz_account_admin_ms',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'predis',
      'options' => 
      array (
        'cluster' => 'predis',
        'prefix' => 'wizbrand_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => 0,
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'password' => NULL,
        'port' => '6379',
        'database' => 1,
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'cloud' => 's3',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\xampp\\htdocs\\wizbrand\\wz-account-admin-ms\\storage\\app',
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\xampp\\htdocs\\wizbrand\\wz-account-admin-ms\\storage\\app/public',
        'url' => 'https://www.wizbrand.com//storage',
        'visibility' => 'public',
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
      ),
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 1024,
      'threads' => 2,
      'time' => 2,
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'daily',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'C:\\xampp\\htdocs\\wizbrand\\wz-account-admin-ms\\storage\\logs/laravel.log',
        'level' => 'debug',
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'C:\\xampp\\htdocs\\wizbrand\\wz-account-admin-ms\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'critical',
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
      ),
    ),
  ),
  'mail' => 
  array (
    'driver' => 'smtp',
    'host' => 'smtp.mailtrap.io',
    'port' => '2525',
    'from' => 
    array (
      'address' => 'info@wizbrand.com',
      'name' => 'wizbrand',
    ),
    'encryption' => 'tls',
    'username' => 'b6862ced12b9fa',
    'password' => 'ae71d4b84d334e',
    'sendmail' => '/usr/sbin/sendmail -bs',
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'C:\\xampp\\htdocs\\wizbrand\\wz-account-admin-ms\\resources\\views/vendor/mail',
      ),
    ),
    'log_channel' => NULL,
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'your-queue-name',
        'region' => 'us-east-1',
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
      ),
    ),
    'failed' => 
    array (
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
    'sparkpost' => 
    array (
      'secret' => NULL,
    ),
    'google' => 
    array (
      'client_id' => '346684678449-fbn3ngtcvddprrlmdsjco4kson26nvvi.apps.googleusercontent.com',
      'client_secret' => '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',
      'redirect' => 'https://www.wizbrand.com/auth/google/callback',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => 525600,
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'C:\\xampp\\htdocs\\wizbrand\\wz-account-admin-ms\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'wizbrand_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => false,
    'http_only' => true,
    'same_site' => NULL,
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'C:\\xampp\\htdocs\\wizbrand\\wz-account-admin-ms\\resources\\views',
    ),
    'compiled' => 'C:\\xampp\\htdocs\\wizbrand\\wz-account-admin-ms\\storage\\framework\\views',
  ),
  'debug-server' => 
  array (
    'host' => 'tcp://127.0.0.1:9912',
  ),
  'passport' => 
  array (
    'private_key' => NULL,
    'public_key' => NULL,
  ),
  'captcha' => 
  array (
    'secret' => '6Ld4FLoUAAAAAAUk52obTEVfuKloVA0YkW2LXDJ_',
    'sitekey' => '6Ld4FLoUAAAAAHmIhTCowy38KqgfR3QfoJJQj6IW',
    'options' => 
    array (
      'timeout' => 30,
    ),
  ),
  'trustedproxy' => 
  array (
    'proxies' => NULL,
    'headers' => 30,
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
