<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Organisation;
use App\Usersorganization;
use Log;
use App\User;


class PhoneNumberController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }
    
    public function index($org_slug){
        $org = Organisation::where('org_slug',$org_slug)->first();
        // $user_id = $org['org_user_id'];
        $user_id = Auth::user()->id;
        $org_id = $org['id'];
        $slug_id = $org['id'];
        $org_users = Usersorganization::where('u_org_user_id',$user_id)->where('u_org_organization_id',$org_id)->first();

        $a_user_api_bearer_token = $this->getPhoneNummberAccessToken();
        // ========= phone number will be display who is assign for this slug name open
        $manager_rol = '2';
        $web_user_rol = '3';   
        $phone_number_user = Usersorganization::where('u_org_organization_id',$org_id)->where('u_org_user_email','!=' ,NULL)->where('u_org_role_id',$manager_rol)->orwhere('u_org_role_id',$web_user_rol)->get();
        Log::info('phone_number_user organization main email find ho gaya');



        // phone number main admin manager and user ka email ana chahiye open
        $userorg_list = Organisation::where('org_slug',$org_slug)->first();
        $slug_name_find = $userorg_list['id'];
        $org_id = $userorg_list['id']; 
        
        $find_org_user_email_phonenumber = Usersorganization::select('u_org_user_email')->where('u_org_organization_id',$slug_name_find)->where('u_org_organization_id',$org_id)->where('u_org_user_email','!=' , NULL)->GroupBy('u_org_user_email')
        ->get();

        // phone number main admin manager and user ka email ana chahiye close
        
        // email id will be display on phone number open
        // interval task for manager open
        // $manager_rol = '2';
        // $web_user_rol = '3'; 
        // $find_org_user_email_phonenumber = Usersorganization::select('u_org_user_email')->where('u_org_organization_id',$org_id)->where('u_org_user_email','!=' ,NULL)->where('u_org_role_id',$manager_rol)->orwhere('u_org_role_id',$web_user_rol)->GroupBy('u_org_user_email')
        // ->get();
        // interval task for manager close

        // ####################

        $userorg_list = Organisation::where('org_slug',$org_slug)->first();
        $slug_name_find = $userorg_list['id'];
        $org_id = $userorg_list['id']; 
        
        $phone_getting_user_manager = Usersorganization::select('u_org_user_email')->where('u_org_organization_id',$slug_name_find)->where('u_org_organization_id',$org_id)->where('u_org_user_email','!=' , NULL)->GroupBy('u_org_user_email')
        ->get(); 
        Log::info('phone getting user manager main assign organization main  in admin page -> ');
        // #####################

        // email id will be display on phone number close

        // ========= phone number will be display who is assign for this slug name close
         // ################# if condition apply for checking if organization has been blocked not allow to access dashboard 
         $block_or_blocked = $org_users['status'];
         $user_account_block = User::where('id',$user_id)->first();
         $block_user = $user_account_block['status'];
         
         if($block_or_blocked == 1){
             Log::info('organizatio block ho gaya hai');
             return view('admin/block-organization'); 
         }
         if($block_user == 1){
             Log::info('user account block ho gaya hai');
             return view('admin/status-blocked'); 
         }
         if($block_or_blocked == NULL){
             Log::info('epmty ho gaya status');
             return view('admin/remove-orgs');
         }
         else{
         // ##################### if condition apply for checking if organization has been blocked not allow to access dashboard 
  
        
        // open condition open
         $getting_roll_id = $org_users->u_org_role_id;
         if($getting_roll_id ==1){
             return view('pages.phonenumber',compact('org_slug','getting_roll_id','a_user_api_bearer_token','slug_id','phone_number_user','find_org_user_email_phonenumber','phone_getting_user_manager')); 
         } // first if close
         if($getting_roll_id ==2){
             return view('manager/phonenumber',compact('org_slug','getting_roll_id','a_user_api_bearer_token','slug_id','phone_number_user','find_org_user_email_phonenumber'));
         } // second if close
         return view('user/phonenumber',compact('org_slug','getting_roll_id','a_user_api_bearer_token','slug_id','phone_number_user','find_org_user_email_phonenumber'));
         // open condition close
    }
}

  
    private function getPhoneNummberAccessToken(){
        $currentLoggedInUser = Auth::user();
        $a_user_api_bearer_token = $currentLoggedInUser->createToken('a_user_api_token')-> accessToken;
        return $a_user_api_bearer_token;
    }
}
