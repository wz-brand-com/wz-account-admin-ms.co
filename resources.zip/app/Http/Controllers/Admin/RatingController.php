<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Organisation;
use App\Usersorganization;
use Log;
use App\User;

class RatingController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }
    public function index($org_slug)
    {
        // for team rating user open
        $login_user_id = Auth::user()->id;
        $userorg_list = Organisation::where('org_slug',$org_slug)->first();
        $slug_name_find = $userorg_list['id'];
        $org_id = $userorg_list['id'];
        $find_org_user_email = Usersorganization::where('u_org_organization_id',$slug_name_find)->where('u_org_organization_id',$org_id)->where('u_org_user_email','!=' ,NULL)->get();

        // in manager page manager value will be display open
        $manager_value = '2';
        $find_org_in_manager_page = Usersorganization::where('u_org_organization_id',$slug_name_find)->where('u_org_organization_id',$org_id)->where('u_org_user_email','!=' ,NULL)->where('u_org_role_id',$manager_value)->get();
        // in manager page manager value will be display close

        // for team rating user close
        
        // ================= for manager calling  in admin page open
        $login_id = Auth::user()->id;
        $manager_org_list = Organisation::where('org_slug',$org_slug)->first();
        Log::info('manager org list man kiya aa raha hai .');
        $slug_name_find = $manager_org_list['id'];
        Log::info('slug name main kiya hai . ');
        $org_id = $manager_org_list['id'];
        
        $manager_rol = '2';
        Log::info('org_id ');      
        $teamrating_all_manager = Usersorganization::select('u_org_user_name')->where('u_org_organization_id',$slug_name_find)
        ->where('u_org_organization_id',$org_id)->where('u_org_role_id',$manager_rol)
        ->where('u_org_user_email','!=' ,NULL)->GroupBy('u_org_user_name')->get();
        Log::info('teamrating_all_manager organization main email find ho gaya for admin page'.$teamrating_all_manager);
        //============= for manager calling admin page close
        
      

        // in manager page user will be display open
        $team_user_id = '3';
        $teamrating_all_user = Usersorganization::select('u_org_user_name')->where('u_org_organization_id',$slug_name_find)->where('u_org_organization_id',$org_id)->where('u_org_user_email','!=' ,NULL)->where('u_org_role_id',$team_user_id)->GroupBy('u_org_user_name')->get();
        Log::info('how many use in team rating in user section');
        // in manager page user will be display close

        // second way in manager page user will be display open
        $team_user_id_name = '3';
        $teamrating_all_user_name = Usersorganization::select('u_org_user_name')->where('u_org_organization_id',$slug_name_find)->where('u_org_organization_id',$org_id)->where('u_org_user_email','!=' ,NULL)->where('u_org_role_id',$team_user_id_name)->GroupBy('u_org_user_name')->get();
        Log::info('how many use in team rating in user section' );
        // in manager page user will be display close


        $org = Organisation::where('org_slug',$org_slug)->first();
        // $user_id = $org['org_user_id'];
        $user_id = Auth::user()->id;
        $org_id = $org['id'];  
        $slug_id = $org['id'];
        $org_users = Usersorganization::where('u_org_user_id',$user_id)->where('u_org_organization_id',$org_id)->first();
        $a_user_api_bearer_token = $this->getProjectAccessToken();


        // ################# if condition apply for checking if organization has been blocked not allow to access dashboard 
        $block_or_blocked = $org_users['status'];
        $user_account_block = User::where('id',$user_id)->first();
        $block_user = $user_account_block['status'];
        
        if($block_or_blocked == 1){
            Log::info('organizatio block ho gaya hai');
            return view('admin/block-organization'); 
        }
        if($block_user == 1){
            Log::info('user account block ho gaya hai');
            return view('admin/status-blocked'); 
        }
        if($block_or_blocked == NULL){
            Log::info('epmty ho gaya status');
            return view('admin/remove-orgs');
        }
        else{
        // ##################### if condition apply for checking if organization has been blocked not allow to access dashboard 

         // open condition open
         $getting_roll_id = $org_users->u_org_role_id;
         if($getting_roll_id ==1){
             return view('pages.team_rating',compact('org_slug','getting_roll_id','a_user_api_bearer_token','slug_id','find_org_user_email','teamrating_all_manager','teamrating_all_user','teamrating_all_user_name')); 
         } // first if close
         if($getting_roll_id ==2){
             return view('manager/team_rating',compact('org_slug','getting_roll_id','a_user_api_bearer_token','slug_id','find_org_in_manager_page','teamrating_all_user','teamrating_all_user_name','teamrating_all_manager'));
         } // second if close
         return view('user/team_rating',compact('org_slug','getting_roll_id','a_user_api_bearer_token','slug_id','teamrating_all_manager','teamrating_all_user','teamrating_all_user_name'));
         // open condition close
    }
}

    private function getProjectAccessToken(){
        $currentLoggedInUser = Auth::user();
        $a_user_api_bearer_token = $currentLoggedInUser->createToken('a_user_api_token')-> accessToken;
        return $a_user_api_bearer_token;
    }


    
}



