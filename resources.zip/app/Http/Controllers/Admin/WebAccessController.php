<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Organisation;
use App\Usersorganization;
use Log;
use App\User;
use App\SiteAdminTaskType;

class WebAccessController extends Controller
{
    public function __construct(){
        $this->middleware('auth');
    }

    public function index($org_slug){
        $taskTypeFromSiteAdmin = SiteAdminTaskType::all();
        $org = Organisation::where('org_slug',$org_slug)->first();
        // $user_id = $org['org_user_id'];
        $user_id = Auth::user()->id;
        $org_id = $org['id'];
        $slug_id = $org['id'];
        $org_users = Usersorganization::where('u_org_user_id',$user_id)->where('u_org_organization_id',$org_id)->first();
        $a_user_api_bearer_token = $this->getWebAccessToken();
        
        // ========= web access will be display who is assign for this slug name open
        // $manager_rol = '2';
        // $web_user_rol = '3';   
        // $web_access_user = Usersorganization::select('u_org_user_email')->where('u_org_organization_id',$org_id)->where('u_org_user_email','!=' ,NULL)->where('u_org_role_id',$manager_rol)->orwhere('u_org_role_id',$web_user_rol)->GroupBy('u_org_user_email')
        // ->get();
        
        Log::info('web_access_user organization GroupBy');

        $userorg_list = Organisation::where('org_slug',$org_slug)->first();
        $slug_name_find = $userorg_list['id'];
        $org_id = $userorg_list['id']; 
        $web_access_user = Usersorganization::select('u_org_user_email')->where('u_org_organization_id',$slug_name_find)->where('u_org_organization_id',$org_id)->where('u_org_user_email','!=' , NULL)->GroupBy('u_org_user_email')
        ->get(); 
        // ========= web access will be display who is assign for this slug name close
        
         // ################# if condition apply for checking if organization has been blocked not allow to access dashboard 
         $block_or_blocked = $org_users['status'];
         $user_account_block = User::where('id',$user_id)->first();
         $block_user = $user_account_block['status'];
         
         if($block_or_blocked == 1){
             Log::info('organizatio block ho gaya hai');
             return view('admin/block-organization'); 
         }
         if($block_user == 1){
             Log::info('user account block ho gaya hai');
             return view('admin/status-blocked'); 
         }
         if($block_or_blocked == NULL){
             Log::info('epmty ho gaya status');
             return view('admin/remove-orgs');
         }
         else{
         // ##################### if condition apply for checking if organization has been blocked not allow to access dashboard 
 
        // open condition open
         $getting_roll_id = $org_users->u_org_role_id;
         Log::info('role id le kr aaa rha hai tas page');
         if($getting_roll_id ==1){
             return view('pages.webaccess',compact('org_slug','getting_roll_id','a_user_api_bearer_token','slug_id','web_access_user','taskTypeFromSiteAdmin')); 
         } // first if close
         if($getting_roll_id ==2){
             return view('manager/webaccess',compact('org_slug','getting_roll_id','a_user_api_bearer_token','slug_id','web_access_user','taskTypeFromSiteAdmin'));
         } // second if close
         return view('user/webaccess',compact('org_slug','getting_roll_id','a_user_api_bearer_token','slug_id','web_access_user','taskTypeFromSiteAdmin'));
         // open condition close
    }

}

  
    private function getWebAccessToken(){
        $currentLoggedInUser = Auth::user();
        $a_user_api_bearer_token = $currentLoggedInUser->createToken('a_user_api_token')->accessToken;
        return $a_user_api_bearer_token;
    }
}
