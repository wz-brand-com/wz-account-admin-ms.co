<!DOCTYPE html>
<html>

<head>
    <title>WizBrand Activate Account</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" />
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <style>
        @import url("https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;700;900&display=swap");

        *,
        body {
            font-family: "Poppins", sans-serif;
            font-weight: 400;
            -webkit-font-smoothing: antialiased;
            text-rendering: optimizeLegibility;
            -moz-osx-font-smoothing: grayscale;
        }

        html,
        body {
            /* background-color: #152733; */
            background-image: url("{{asset('/img/login-register.jpg')}}");
            background-size: cover;
            background-repeat: no-repeat;

        }

        .form-holder {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            text-align: center;
            min-height: 100vh;
        }

        .form-holder .form-content {
            position: relative;
            text-align: center;
            display: -webkit-box;
            display: -moz-box;
            display: -ms-flexbox;
            display: -webkit-flex;
            display: flex;
            -webkit-justify-content: center;
            justify-content: center;
            -webkit-align-items: center;
            align-items: center;
            padding: 60px;
        }

        .form-content .form-items {
            border: 3px solid #fff;
            padding: 40px;
            display: inline-block;
            width: 100%;
            min-width: 540px;
            -webkit-border-radius: 10px;
            -moz-border-radius: 10px;
            border-radius: 10px;
            text-align: left;
            -webkit-transition: all 0.4s ease;
            transition: all 0.4s ease;
        }

        .form-content h3 {
            color: #fff;
            text-align: left;
            font-size: 28px;
            font-weight: 600;
            margin-bottom: 5px;
        }

        .form-content h3.form-title {
            margin-bottom: 30px;
        }

        .form-content p {
            color: #fff;
            text-align: left;
            font-size: 17px;
            font-weight: 300;
            line-height: 20px;
            margin-bottom: 30px;
        }

        .form-content label,
        .was-validated .form-check-input:invalid~.form-check-label,
        .was-validated .form-check-input:valid~.form-check-label {
            color: #fff;
        }

        .form-content input[type="text"],
        .form-content input[type="password"],
        .form-content input[type="email"],
        .form-content select {
            width: 100%;
            padding: 9px 20px;
            text-align: left;
            border: 0;
            outline: 0;
            border-radius: 6px;
            background-color: #fff;
            font-size: 15px;
            font-weight: 300;
            color: #8d8d8d;
            -webkit-transition: all 0.3s ease;
            transition: all 0.3s ease;
            margin-top: 16px;
        }

        .btn-primary {
            background-color: #3333ff;
            outline: none;
            border: 0px;
            box-shadow: none;
        }

        .btn-primary:hover,
        .btn-primary:focus,
        .btn-primary:active {
            background-color: #495056;
            outline: none !important;
            border: none !important;
            box-shadow: none;
        }

        .form-content textarea {
            position: static !important;
            width: 100%;
            padding: 8px 20px;
            border-radius: 6px;
            text-align: left;
            background-color: #fff;
            border: 0;
            font-size: 15px;
            font-weight: 300;
            color: #8d8d8d;
            outline: none;
            resize: none;
            height: 120px;
            -webkit-transition: none;
            transition: none;
            margin-bottom: 14px;
        }

        .form-content textarea:hover,
        .form-content textarea:focus {
            border: 0;
            background-color: #ebeff8;
            color: #8d8d8d;
        }

        /* .mv-up {
            margin-top: -9px !important;
            margin-bottom: 8px !important;
        }

        .invalid-feedback {
            color: #ff606e;
        }

        #invalid-feedback {
            color: #ff606e;
        }


        .valid-feedback {
            color: #2acc80;
        } */

    </style>
</head>

<body class="container">
    <div class="box">
        <div class="form-body" style="margin-left: 254px">
            <div class="row">
                <div class="form-holder">
                    <div class="form-content">
                        <div class="form-items" style="background-color: #152733;">
                            <h3 class="text-center">Activate Your Account</h3>

                            <form id="form" method="post" action="{{route('activate.store')}}">
                                @csrf

                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-group">
                                            <input class="form-control" placeholder="Username" type="text" id="name" name="name"
                                                value="{{$user_getting_name}}" disable>
                                        </div>
                                        <div class="form-group">
                                            <input type="email" class="form-control" name="email" id="email"
                                                value="{{$getting_mail}}" disabled>
                                        </div>

                                        <div class="form-group">
                                            <input type="password" class="form-control" name="password" id="password"
                                                name="password" placeholder="password">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control" name="confirmPassword"
                                                id="confirmPassword" placeholder="confirm password">
                                        </div>
                                    </div>
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input class="form-control" placeholder="Enter Mobile bumber" type="text" id="mobile" name="mobile">
                                    </div>
                                    <div class="form-group">
                                        <select name="country_id" class="countries form-control" id="countryId"
                                            value="{{old('country')}}">
                                            <option value=""> Select Country </option>
                                        </select>
                                       
                                    </div>
                                    <div class="form-group">
                                        <select name="state_id" class="states form-control" id="stateId">
                                            <option value="">Select State</option>
                                        </select>

                                    </div>
                                    <div class="form-group">
                                        <select name="city_id" class="cities form-control" id="cityId">
                                            <option value="">Select City</option>
                                        </select>
                                      
                                    </div>

                                    <input type="hidden" value="{{$getting_token}}" name="tokenIsComming">
                                    <input type="submit" class="btn btn-primary" value="Submit" />
                                </div>
                            </div>

                            </form>
                          
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
<style>
    .messages {
        color: red;

    }

</style>
<script>
    $(document).ready(function () {
        $('#form').validate({
            rules: {

                password: {
                    required: true,
                    minlength: 8
                },
                countryId: {
                    required: true,

                },
                confirmPassword: {
                    required: true,
                    equalTo: "#password"

                }
            },
            messages: {
                name: 'Please enter Name.',
                email: {
                    required: 'Please enter Email Address.',
                    email: 'Please enter a valid Email Address.',
                },

                password: {
                    required: 'Please enter Password.',
                    minlength: 'Password must be at least 8 characters long.',
                },
                countryId: {
                    required: 'Please enter country.',
                    minlength: 'Please select country.',
                },
                confirmPassword: {
                    required: 'Please enter Confirm Password.',
                    equalTo: 'Confirm Password do not match with Password.',
                }
            },
            submitHandler: function (form) {
                form.submit();
            }
        });
    });

</script>
<script>
    (function () {
        "use strict";
        const forms = document.querySelectorAll(".requires-validation");
        Array.from(forms).forEach(function (form) {
            form.addEventListener(
                "submit",
                function (event) {
                    if (!form.checkValidity()) {
                        event.preventDefault();
                        event.stopPropagation();
                    }

                    form.classList.add("was-validated");
                },
                false
            );
        });
    })();

</script>
<script src="{{ asset('js/location.js') }}"></script>
</html>
